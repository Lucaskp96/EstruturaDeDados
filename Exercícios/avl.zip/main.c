#include <stdio.h>
#include <stdlib.h>

int main()
{
/*** "arvore" armazena o endereço do primeiro elemento da arvore ***/
    Apontador* arvore = create_tree();

    return 0;
}
